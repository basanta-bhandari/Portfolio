# Music Mosaic

A local-first music discovery prototype. Every visitor starts with an empty profile. Artist search uses MusicBrainz; candidate recordings and community tags come from ListenBrainz. The client ranks results using listening paths, tag overlap, the chosen context, discovery level, and explicit feedback.

## Run locally

Serve `dist/` with any static HTTP server, for example:

```sh
python3 -m http.server 8765 --directory dist
```

The code has no build step or third-party JavaScript dependencies.

## Data

The app uses IndexedDB only after the visitor enables local history. Before that, interactions affect the current page session but are not persisted. The profile can be exported and imported as versioned JSON. No analytics are included. Artist searches go to MusicBrainz and selected artist IDs go to ListenBrainz; the activity log is never sent. Spotify and Apple Music links open provider searches; the prototype does not host audio or provide account playback.

## Recommendation model

`dist/app.js` contains candidate retrieval, scoring, feedback, and the diversity pass. `dist/graph.js` builds an interactive graph from the current artists, recommended recordings, and community tags. The model is intentionally inspectable. It does not analyze audio, voice, or lyrics directly and does not claim to infer life phases. The 1,500 most recent actions are retained when local history is enabled. Public catalog availability and coverage affect results.

## Provider playback

Provider account playback requires developer registrations and credentials. Spotify's Web Playback SDK requires Spotify Premium and a registered application. Apple Music's web playback requires MusicKit registration and a signed developer token. No provider secrets should be committed or included in browser code.

## License

MIT. See `LICENSE`.
