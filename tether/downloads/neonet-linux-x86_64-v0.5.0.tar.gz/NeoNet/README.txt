NeoNet (Tether) for x86-64 Arch-based Linux

Extract this archive and run ./install.sh as your normal user. Open NeoNet (Tether) from your app launcher. The GUI needs a working graphical desktop and its system graphics libraries. No privileged core service is installed.
