#!/usr/bin/env sh
set -eu
dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
bin_dir="${HOME}/.local/bin"
app_dir="${XDG_DATA_HOME:-${HOME}/.local/share}/applications"
icon_dir="${XDG_DATA_HOME:-${HOME}/.local/share}/icons/hicolor/scalable/apps"
mkdir -p "$bin_dir" "$app_dir" "$icon_dir"
install -m 0755 "$dir/neonet" "$bin_dir/neonet"
install -m 0644 "$dir/neonet.svg" "$icon_dir/neonet.svg"
cat > "$app_dir/neonet.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=NeoNet (Tether)
Comment=Private messages and files across trusted devices
Exec="$bin_dir/neonet" gui
Icon=neonet
Terminal=false
Categories=Network;InstantMessaging;
DESKTOP
chmod 0644 "$app_dir/neonet.desktop"
printf 'Installed NeoNet to %s and its desktop launcher to %s\n' "$bin_dir/neonet" "$app_dir/neonet.desktop"
